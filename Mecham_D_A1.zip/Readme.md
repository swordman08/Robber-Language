Decker Mecham
dmecham@chapman.edu
CPSC 350 (Chapman University) : Rene German
Assignment Name : Robber Language Translation (Rövarspråket language)

Abstract:

Translate english to robber language without the use of any non-primitive data structures. (No arrays, Vectors, Lists, etc)
Just use individual primitive variables (int, double, etc) and std strings. 

Commands to compile / run:

To compile
    g++ *.cpp 
To run
    ./a.out



Bugs:    N/A     none that I am aware of.



Sources:
    https://www.geeksforgeeks.org/how-to-convert-a-single-character-to-string-in-cpp/

    https://cplusplus.com/reference/cctype/

    https://www.geeksforgeeks.org/file-handling-c-classes/

    https://www.geeksforgeeks.org/getline-string-c/

    https://html.com/#Creating_Your_First_HTML_Webpage